import express from "express";
import axios from "axios";
import TelegramBot from "node-telegram-bot-api";

const BOT_TOKEN = process.env.BOT_TOKEN;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const ADMIN_ID = process.env.ADMIN_ID;

const bot = new TelegramBot(BOT_TOKEN);
const app = express();

app.use(express.json());

app.post("/", async (req, res) => {
  const update = req.body;
  if (!update.message) return res.sendStatus(200);

  const chatId = update.message.chat.id;
  const text = update.message.text || "";

  try {
    if (text === "/start") {
      const buttons = {
        inline_keyboard: [
          [
            { text: "💬 AMA", url: "https://t.me/DragonsAI" },
            { text: "🌐 Join Channel", url: "https://t.me/dragonstrending" }
          ]
        ]
      };
      const welcome = `🔥 <b>Welcome to Dragon AI!</b> 🔥\n\nI’m your ⚡ <b>ChatGPT-4 AI Assistant</b> for <b>Dragons Trend</b> 🐉.\n• Ask about the community and <b>$DRGN</b>\n• /fetch <CA> for token info\n• /generate for AI images\nTap a button below 👇`;
      await bot.sendMessage(chatId, welcome, { parse_mode: "HTML", reply_markup: buttons });
      return res.sendStatus(200);
    }

    if (text.startsWith("/fetch ")) {
      const contract = text.split(" ")[1];
      await bot.sendMessage(chatId, `🔍 Fetching token info for <b>${contract}</b>...`, { parse_mode: "HTML" });
      const { data } = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${contract}`);
      const pair = data.pairs?.[0];
      if (!pair) return await bot.sendMessage(chatId, "❌ Token not found!", { parse_mode: "HTML" });
      const msg = `📊 <b>Token Info</b>\n💠 <b>Name:</b> ${pair.baseToken.name}\n🔹 <b>Symbol:</b> ${pair.baseToken.symbol}\n💰 <b>Price:</b> $${pair.priceUsd}\n📉 <b>Chart:</b> <a href="${pair.url}">View</a>`;
      await bot.sendMessage(chatId, msg, { parse_mode: "HTML" });
      return res.sendStatus(200);
    }

    if (text.startsWith("/generate ")) {
      const prompt = text.substring(10).trim();
      await bot.sendMessage(chatId, `🖌️ Generating image for: <b>${prompt}</b>...`, { parse_mode: "HTML" });
      const response = await axios.post("https://api.openai.com/v1/images/generations", {
        model: "gpt-image-1",
        prompt,
        size: "1024x1024",
        n: 1
      }, { headers: { Authorization: `Bearer ${OPENAI_API_KEY}` } });
      const img = response.data.data?.[0]?.url;
      await bot.sendPhoto(chatId, img, { caption: `Generated: <b>${prompt}</b>`, parse_mode: "HTML" });
      return res.sendStatus(200);
    }

    if (!text.startsWith("/")) {
      const thinking = await bot.sendMessage(chatId, "🤖💭 <b>Dragon AI is thinking...</b> 🐲", { parse_mode: "HTML" });
      const reply = await axios.post("https://api.openai.com/v1/chat/completions", {
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are Dragon AI assistant." },
          { role: "user", content: text }
        ]
      }, { headers: { Authorization: `Bearer ${OPENAI_API_KEY}` } });
      const msg = reply.data.choices?.[0]?.message?.content || "🐲 Sorry, I couldn't process that.";
      await bot.sendMessage(chatId, msg, { parse_mode: "HTML" });
      await bot.deleteMessage(chatId, thinking.message_id);
    }
    res.sendStatus(200);
  } catch (err) {
    console.error(err.message);
    res.sendStatus(200);
  }
});

export default app;
